Some VStar plug-ins are reliant upon freely available open source libraries that
are distributed as Java archive files ("jar" files) and are described below.

The following libraries are present in the current directory (lib) for VStar 
plug-in development and deployment:

  tamfits.jar from the TopCat starjava distribution for reading files in FITS format:
  o http://www.star.bris.ac.uk/~mbt/topcat/#starjava
  o GNU General Public License
    gpl-3.0.txt
    http://www.gnu.org/copyleft/gpl.html
